<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1734368772881'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/home/runner/work/megit/megit/com.eclipsesource.megit.product/target/products/com.eclipsesource.megit/win32/win32/x86_64/MeGit'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=win32,osgi.arch=x86_64,osgi.ws=win32,osgi.nl=en'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/home/runner/work/megit/megit/com.eclipsesource.megit.product/target/products/com.eclipsesource.megit/win32/win32/x86_64/MeGit'/>
  </properties>
</profile>
